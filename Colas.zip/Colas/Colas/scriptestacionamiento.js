let autos = [];

function mostrarFormularioIngreso() {
    document.getElementById('formularioIngreso').style.display = 'block';
    document.getElementById('formularioRetiro').style.display = 'none';
}

function mostrarFormularioRetiro() {
    document.getElementById('formularioIngreso').style.display = 'none';
    document.getElementById('formularioRetiro').style.display = 'block';
}

function ingresarAuto() {
    const placas = document.getElementById('placas').value.trim();
    const propietario = document.getElementById('propietario').value.trim();
    const regexPlacas = /^[A-Za-z0-9]{3}-[A-Za-z0-9]{3}$/;

    if (!regexPlacas.test(placas)) {
        alert('Las placas deben tener el formato XXX-XXX (letras o números).');
        return;
    }

    if (!propietario) {
        alert('El nombre del propietario no puede estar vacío.');
        return;
    }

    const autoExistente = autos.find(auto => auto.placas.toLowerCase() === placas.toLowerCase());
    if (autoExistente) {
        alert(`Ya existe un auto con las placas ${placas} en el estacionamiento.`);
        return;
    }

    const auto = {
        placas: placas,
        propietario: propietario,
        horaEntrada: new Date()
    };

    autos.push(auto);
    document.getElementById('formularioIngreso').style.display = 'none';
    alert(`Auto con placas ${placas} ingresado correctamente.`);
    document.getElementById('placas').value = ''; 
    document.getElementById('propietario').value = '';
}

function retirarAutoPorPlaca() {
    const placasRetiro = document.getElementById('placasRetiro').value.trim();
    const regexPlacas = /^[A-Za-z0-9]{3}-[A-Za-z0-9]{3}$/;

    if (!regexPlacas.test(placasRetiro)) {
        alert('Las placas deben tener el formato XXX-XXX (letras o números).');
        return;
    }

    const index = autos.findIndex(auto => auto.placas.toLowerCase() === placasRetiro.toLowerCase());

    if (index !== -1) {
        const auto = autos.splice(index, 1)[0];
        const horaSalida = new Date();
        const tiempoEstacionado = (horaSalida - auto.horaEntrada) / 1000; 
        const costo = tiempoEstacionado * 2.0;

        document.getElementById('resultado').innerHTML = `
            <p><strong>Auto retirado:</strong></p>
            <p>Placas: ${auto.placas}</p>
            <p>Propietario: ${auto.propietario}</p>
            <p>Hora de entrada: ${auto.horaEntrada}</p>
            <p>Hora de salida: ${horaSalida}</p>
            <p>Tiempo estacionado: ${tiempoEstacionado.toFixed(2)} segundos</p>
            <p>Costo: $${costo.toFixed(2)} pesos</p>
        `;
    } else {
        alert(`No se encontró un auto con las placas ${placasRetiro}.`);
    }
    document.getElementById('formularioRetiro').style.display = 'none';
    document.getElementById('placasRetiro').value = ''; 
}

function mostrarAutos() {
    if (autos.length === 0) {
        document.getElementById('resultado').innerHTML = '<p>No hay autos en el estacionamiento.</p>';
    } else {
        let resultadoHTML = '<p><strong>Autos en el estacionamiento:</strong></p>';
        autos.forEach(auto => {
            resultadoHTML += `
                <p>- Placas: ${auto.placas}, Propietario: ${auto.propietario}, Hora de entrada: ${auto.horaEntrada}</p>
            `;
        });
        document.getElementById('resultado').innerHTML = resultadoHTML;
    }
}

function salir() {
    document.getElementById('resultado').innerHTML = 'Gracias por usar el sistema de estacionamiento.';
    document.getElementById('formularioIngreso').style.display = 'none';
    document.getElementById('formularioRetiro').style.display = 'none';
}
