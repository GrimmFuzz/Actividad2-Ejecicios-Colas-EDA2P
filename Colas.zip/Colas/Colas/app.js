class Cola {
    constructor() {
        this.items = [];
    }

    // Añadir un elemento a la cola
    encolar(Nturno, Cliente, Movimiento, Fecha, Hora) {
        const tiempoAgregado = new Date(); // Guardar el tiempo de adición
        this.items.push({ Nturno, Cliente, Movimiento, Fecha, Hora, tiempoAgregado });
    }
    
    // Eliminar el primer elemento de la cola
    desencolar() {
        if (this.estaVacia()) {
            return null; // Cambiar a null para que sea más claro que no hay elementos
        }
        return this.items.shift(); // Devuelve el elemento desencolado
    }

    // Mostrar el primer elemento de la cola sin eliminarlo
    frente() {
        if (this.estaVacia()) {
            return null;
        }
        return this.items[0];
    }

    // Verificar si la cola está vacía
    estaVacia() {
        return this.items.length === 0;
    }

    // Mostrar todos los elementos de la cola en una tabla
    mostrarCola() {
        const tbody = document.querySelector('#tablaCola tbody');
        tbody.innerHTML = ''; // Limpiar la tabla

        // Generar nuevas filas basadas en los elementos de la cola
        this.items.forEach(item => {
            const fila = `
                <tr>
                    <td>${item.Nturno}</td>
                    <td>${item.Cliente}</td>
                    <td>${item.Movimiento}</td>
                    <td>${item.Fecha}</td>
                    <td>${item.Hora}</td>
                </tr>
            `;
            tbody.innerHTML += fila; // Insertar la nueva fila
        });
    }

    // Buscar un turno específico
    buscarTurno(Nturno) {
        return this.items.some(item => item.Nturno === Nturno);
    }
}

// Crear instancia de la Cola
const cola = new Cola();

// Variable global para el último número de turno
let ultimoTurno = 0; // Inicia en 0, se incrementará al agregar un nuevo cliente

function AgregarElemento() {
    const fechaActual = new Date();
    const año = fechaActual.getFullYear();
    const mes = fechaActual.getMonth() + 1; 
    const dia = fechaActual.getDate();

    const horas = fechaActual.getHours();
    const minutos = fechaActual.getMinutes();
    const segundos = fechaActual.getSeconds();

    const Nturno = (ultimoTurno + 1).toString(); // Incrementa el turno automáticamente
    const Cliente = document.getElementById('cliente').value;
    const Movimiento = document.getElementById('listamovimiento').value;
    const Fecha = (`${dia}/${mes}/${año}`);
    const Hora = (`${horas}:${minutos}:${segundos}`);

    // Validar que el nombre del cliente solo contenga letras y espacios
    const letrasRegex = /^[A-Za-z\s]+$/; // Solo permite letras y espacios
    if (!letrasRegex.test(Cliente)) {
        alert('El nombre del cliente solo puede contener letras y espacios.');
        return;
    }

    // Validar que el nombre del cliente no exceda 50 caracteres
    if (Cliente.length > 50) {
        alert('El nombre del cliente no puede exceder 50 caracteres.');
        return;
    }

    // Encolar el elemento
    cola.encolar(Nturno, Cliente, Movimiento, Fecha, Hora);
    alert(`Cliente agregado:\nNombre: ${Cliente}\nTurno: ${Nturno}\nMovimiento: ${Movimiento}\nFecha: ${Fecha}\nHora: ${Hora}`);

    // Actualizar el último turno
    ultimoTurno++; // Incrementar el número de turno

    // Limpiar los campos
    document.getElementById('Nturno').value = (ultimoTurno + 1).toString(); // Mostrar el siguiente número de turno
    document.getElementById('cliente').value = ''; 
    document.getElementById('listamovimiento').value = 'Pago de Servicio'; 
    document.getElementById('estadoCola').innerHTML = cola.mostrarCola();
}

// Inicializa el campo de número de turno al cargar la página
document.getElementById('Nturno').value = (ultimoTurno + 1).toString(); // Inicializa el campo

function desencolarElemento() {
    const elementoDesencolado = cola.desencolar(); // Desencola el primer elemento

    if (elementoDesencolado) {
        const tiempoActual = new Date();
        const tiempoTranscurrido = Math.floor((tiempoActual - elementoDesencolado.tiempoAgregado) / 1000); // en segundos

        // Calcular horas, minutos y segundos
        const horas = Math.floor(tiempoTranscurrido / 3600);
        const minutos = Math.floor((tiempoTranscurrido % 3600) / 60);
        const segundos = tiempoTranscurrido % 60;

        // Mostrar alerta con el nombre del cliente y el tiempo transcurrido
        alert(`Cliente desencolado:\nNombre: ${elementoDesencolado.Cliente}\nTiempo en cola: ${horas} horas, ${minutos} minutos, ${segundos} segundos`);
    } else {
        alert('No hay elementos en la cola para desencolar.');
    }

    cola.mostrarCola(); // Actualiza la tabla después de desencolar
}

function handleClick(action) {
    document.getElementById('Banco').style.display = 'none';
    document.getElementById('Estacionamiento').style.display = 'none';
    document.getElementById('JuegoPintarCoches').style.display = 'none';
    switch (action) {
        case 'Banco':
            document.getElementById('Banco').style.display = 'block';
            document.getElementById('Estacionamiento').style.display = 'none';
            document.getElementById('JuegoPintarCoches').style.display = 'none';
            break;
         case 'JuegoPintarCoches':
            document.getElementById('JuegoPintarCoches').style.display = 'block';
            document.getElementById('Estacionamiento').style.display = 'none';
            document.getElementById('Banco').style.display = 'none';
            break;
        case 'Estacionamiento':
            document.getElementById('Banco').style.display = 'none';
            document.getElementById('Estacionamiento').style.display = 'block';
            document.getElementById('JuegoPintarCoches').style.display = 'none';
            break;
    }
}

