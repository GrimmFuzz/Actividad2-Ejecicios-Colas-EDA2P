let carQueue = [];
let paintedCars = 0;
let timer = 0;
let interval;
let paintingSpeed = 20000; // 20 segundos
let gameActive = false; // Cambiado a false por defecto
const maxCars = 5;

// Inicializar el Juego
function initGame() {
    carQueue = [];
    paintedCars = 0;
    timer = 0;
    paintingSpeed = 20000;
    gameActive = false; // Cambiado a false por defecto
    document.getElementById('score').innerText = 'Carros pintados: 0';
    document.getElementById('timer').innerText = 'Tiempo: 0s';
    clearInterval(interval);
}

// Actualizar el Temporizador
function updateTimer() {
    if (!gameActive) return;
    timer++;
    document.getElementById('timer').innerText = `Tiempo: ${timer}s`;
}

// Añadir un Carro a la Cola
function enqueueCar() {
    if (carQueue.length >= maxCars) {
        endGame();
        return;
    }
    const newCar = {
        color: getRandomColor(),
        painted: false,
    };
    carQueue.push(newCar);
    updateQueueUI();
    setTimeout(enqueueCar, paintingSpeed);
}

// Actualizar la Interfaz de la Cola
function updateQueueUI() {
    // Limpia todos los carros visibles
    for (let i = 0; i < maxCars; i++) {
        const carElement = document.getElementById(`car${i + 1}`);
        if (i < carQueue.length) {
            const car = carQueue[i];
            carElement.style.backgroundColor = car.painted ? car.color : '#ccc';
            carElement.innerText = car.color;
        } else {
            carElement.style.backgroundColor = '#ccc';
            carElement.innerText = '';
        }
    }
}

// Generador de Color Aleatorio
function getRandomColor() {
    const colors = ['Naranja', 'Rojo', 'Verde', 'Amarillo'];
    return colors[Math.floor(Math.random() * colors.length)];
}

// Pintar el Primer Carro en la Cola
function paintCar(color) {
    if (!gameActive || carQueue.length === 0) return;
    const firstCar = carQueue[0];
    if (firstCar.color === color) {
        firstCar.painted = true;
        paintedCars++;
        document.getElementById('score').innerText = `Carros pintados: ${paintedCars}`;
        carQueue.shift(); // Elimina el primer carro pintado
        updateQueueUI();

        // Aumentar dificultad después de cada 3 carros pintados
        if (paintedCars % 3 === 0 && paintingSpeed > 5000) {
            paintingSpeed -= 2000; // Aumenta la velocidad
        }
    } else {
        alert("¡Color incorrecto! Debes pintar con el color que se muestra.");
    }

    // Fin del juego si la cola está llena
    if (carQueue.length >= maxCars) {
        endGame();
    }
}

// Terminar el Juego
function endGame() {
    gameActive = false;
    clearInterval(interval);
    alert(`Juego terminado! Carros pintados: ${paintedCars}, Tiempo total: ${timer}s`);
}

// Iniciar el Juego al presionar el botón
document.getElementById('startButton').addEventListener('click', () => {
    initGame(); // Reinicia el juego
    gameActive = true; // Activa el juego
    interval = setInterval(updateTimer, 1000); // Inicia el temporizador
    enqueueCar(); // Comienza a agregar carros
});

// Eventos de los botones de color
document.querySelectorAll('.color-btn').forEach(button => {
    button.addEventListener('click', () => {
        const color = button.getAttribute('data-color');
        paintCar(color);
    });
});
